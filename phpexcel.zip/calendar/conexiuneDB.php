<?php
// PHP 5
// class definition
class ConexiuneDB {
//clasa necesara conectarii la o baza de date
// define properties
public $con; 
public $baza_date;
public $tableName;
public $fieldName;
public $sql;
public $sqlFile;


// constructor 
    public function __construct($site,$utilizator,$parola) { 
        $this->con = mysql_connect($site,$utilizator,$parola);// stabileste conexiunea cu MySQL 
	
    } 
// define methods
    public function InchideConexiunea()
    {
    mysql_close($this->con);
    }
     public function Interogare($baza_date,$sqlFile,$sqlText) {
    //poate prelua query fie dintr-un fisier text - $sqlFile, fie dintr-un sir - $sqlText
//mysql_select_db($baza_date, $this->con);//selecteaza baza de date    	

if(empty($sqlText))
{
$this->sql=file_get_contents($sqlFile) or die("can't open file");
}
else 
{
$this->sql=$sqlText;

}
mysql_select_db($baza_date, $this->con)or die (mysql_error());//selecteaza baza de date

$this->sql  = mysql_query($this->sql,$this->con);

     }
     
 
}
?>
