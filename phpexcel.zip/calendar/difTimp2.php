
<?php
class DifTimp2 {

//clasa necesara calcularii diferentei de timp dintre 2 date calendaristice
// define properties
public $deltaT;
public $semn;

// constructor 
    public function __construct($date1)

    { 
//Atentie formatul datei trebuie sa fie de tipul 12.03.2011
$this->semn="+";
$date2=date('d.m.Y');
$diff = strtotime($date2) - strtotime($date1);
if ($diff<0)
{
$this->semn="-";
$diff=$diff*(-1);
}

$days = floor($diff/ (60*60*24));
$this->deltaT=$days;
 
} 
 
}

?> 
