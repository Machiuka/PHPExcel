
 <html>
<head>
<title>Actualizare Calendar</title>
</head>
<body>

<?php
include 'conexiuneDB.php';
include 'vizualDB.php';
include 'trimiteEmail.php';
echo"<form  method='post'> 
Parola : <input type='password' name='admin' />";


echo'<br><input type="submit" value="Validare"/></form>'; 
$parola=0;

$activitate = $_POST['Activitate'];
$dataActivitate = $_POST['DataActivitate'];
$nrAni = $_POST['NrAni'];
$recurenta = $_POST['Recurenta'];
$email = $_POST['Email'];
if(isset($_POST['admin']))
{
$admin=$_POST['admin'];


if($admin=="qwq")
{
$aBD= new ConexiuneDB("localhost","sorin2_calendar","mihaela98");
$bd="sorin2_blog";     
$parola=1;
}
else
{
	$mesaj="S-a incercat accesul neautorizat la baza de date de la IP-ul ".$_SERVER['REMOTE_ADDR']; 
$mail=new TrimiteEmail("cdl_1996@yahoo.com",$mesaj,"actualizare");
	
}
}
//$queryAdauga = "UPDATE `todo` SET `Activitate` = '$activitate' WHERE `Id` = $id";
$queryAdauga = "INSERT INTO `todo` (`Activitate`, `DataActivitate`, `NrAni`, `Recurenta`, `Email`) VALUES ('$activitate', '$dataActivitate', '$nrAni', '$recurenta', '$email')";
$aBD->Interogare($bd,"query1.txt",$queryAdauga);

$querySterge = "DELETE FROM `todo` WHERE `Activitate` = ''";
$aBD->Interogare($bd,"query1.txt",$querySterge);
$aViz=new VizualDB($bd,"todo","*","");
$aViz;
$mesaj="Baza de date s-a actualizat acum cu urmatoarele date: ".$activitate.", ".$dataActivitate.", ".$recurenta.",".$email."."; 
$mail=new TrimiteEmail("cdl_1996@yahoo.com",$mesaj,"actualizare");
?>
<form method="post" action="<?php $_PHP_SELF ?>">
<table width="600" border="0" cellspacing="1" cellpadding="2">

<tr>
<td width="200">Activitate</td>
<td><input name="Activitate" type="text" id="Activitate"></td>
<td>Aici este descrisa activitatea</td>
</tr>
<tr>
<td width="100"> </td>
<td> </td>
</tr>
<tr>
<td width="100">DataActivitate</td>
<td><input name="DataActivitate" type="text" id="DataActivitate"></td>
<td>Se insereaza data la care se seteaza alerta in forma 12.04.2014</td>
</tr>
<tr>
<td width="100"> </td>
<td> </td>
</tr>
<tr>
<td width="100"> </td>
<td> </td>
</tr>
<tr>
<td width="100">Recurenta</td>
<td><input name="Recurenta" type="text" id="Recurenta"></td>
<td>Se tasteaza a - anual, l - lunar, t- trimestrial, s- semestrial. Daca nu se introduce nimic alerta va fi stearsa la indeplinire</td>
</tr>
<tr>
<td width="100">NrAni</td>
<td><input name="NrAni" type="text" id="NrAni"></td>
<td>Se introduce numarul de ani dupa care se repeta alerta. Ex.2 ani in cazul ITP-urilor, altfel nu se completeaza</td>
</tr>
<tr>
<td width="100"> </td>
<td> </td>
</tr>
<tr>
<td width="200">Email</td>
<td><input name="Email" type="text" id="Email"></td>
<td>Se introduce o singura adresa de email unde se va primi alerta</td>
</tr>


<tr>
<td width="200"> </td>
<td> </td>
</tr>

<tr>
<td width="200"> </td>
<td>
<input name="update" type="submit" id="update" value="Update">
</td>
</tr>

</table>
</form>


</body>
</html>


