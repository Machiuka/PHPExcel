<?php
//include 'conexiune.php';
class VizualDB {


//clasa necesara vizualizarii unei baze de date
// define properties
public $nameTabel;
//public $campTabel;

// constructor 
    public function __construct($baza,$nTabel,$cTabel,$cond)
   // public function __construct($nTabel) 
    { 
        $this->nameTabel = $nTabel; 
        $this->campTabel = $cTabel; 
        $this->conditie = $cond;
	$aBD= new ConexiuneDB("localhost","sorin2_calendar","mihaela98");
//query poate fi luata fie dintr-un sir, fie dintr-un fisier text
 
//$queryTXT="SELECT * FROM ".$this->nameTabel;
if($this->conditie)
{
	$queryTXT="SELECT * FROM ".$this->nameTabel." WHERE ".$this->campTabel."=".$this->conditie;
}
else
{
	$queryTXT="SELECT ".$this->campTabel." FROM ".$this->nameTabel;
}
//echo'<br><h3><u>HELLO Este selectat tabelul "'.$this->nameTabel.'"</u></h3><br>';
if(!empty($this->nameTabel)){

$aBD->Interogare($baza,"query1.txt",$queryTXT);
//$result = mysql_fetch_array( $aBD->sql );
$result = mysql_query( $queryTXT );
$table = mysql_field_name($result, 1);
$num_cols = mysql_num_fields($result);

print "<table width=600 border=1>\n";
for ($i = 0; $i < $num_cols; ++$i) {
    
    $field[$i] = mysql_field_name($result, $i);

print "\t<td><b>$field[$i]</b></td>\n";

}
print "</tr>\n";
while($get_info = mysql_fetch_row($result))

{
foreach ($get_info as $camp)
{

print "\t<td>$camp</td>\n";

}
print "</tr>\n";

}
print "</table>\n";


}
}
}
?> 
