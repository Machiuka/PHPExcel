
<?php
class CalculTermen {

//clasa necesara calculului noului termen al activitatii in baza de date todo in functie de 
//valoarea recurentei lunar, anual, la x ani, trimestrial sau semestrial
// define properties
public $termenNou;


// constructor 
    public function __construct($dataAct, $recur,$ani)

    { 
//Atentie formatul datei trebuie sa fie de tipul 16.04.2014
//$recur poate fi doar:  l, a, t, s
$ziua=substr ( $dataAct , 0 ,2 );
$luna=substr ( $dataAct , 3 ,2 );
$anul=substr ( $dataAct , 6 ,4 );


if ($recur=="l")
{
		if($luna==12) {$luna="01"; $anul=$anul+1;}
		else{
			
			if($luna<10){$luna="0".$luna;}
			else{$luna=$luna+1;}
			
			}
	
}
 else if ($recur=="a")
{
		 if ($ani>1) {$anul=$anul+$ani; }
	 else {	 $anul=$anul+1;}
}
else if ($recur=="t")
{
		if($luna<10)
		{
			$luna=$luna+3;
		if($luna<10){$luna="0".$luna;}
		}
		else if($luna==10) {$luna="01"; $anul=$anul+1;}
		else if($luna==11) {$luna="02"; $anul=$anul+1;}
		else if($luna==12) {$luna="03"; $anul=$anul+1;}
		
	
}
else if ($recur=="s")
{
		if($luna<7)
		{
			$luna=$luna+6;
		if($luna<10){$luna="0".$luna;}
		}
		else if($luna==7) {$luna="01"; $anul=$anul+1;}
		else if($luna==8) {$luna="02"; $anul=$anul+1;}
		else if($luna==9) {$luna="03"; $anul=$anul+1;}
		else if($luna==10) {$luna="04"; $anul=$anul+1;}
		else if($luna==11) {$luna="05"; $anul=$anul+1;}
		else if($luna==12) {$luna="06"; $anul=$anul+1;}
	
}
	$nouaData=$ziua.".".$luna.".".$anul;
$this->termenNou=$nouaData;
}



}



?> 
