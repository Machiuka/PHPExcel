<?php

include 'trimiteEmail.php';

echo"<form  method='post'> 
Parola : <input type='password' name='admin' />";

echo'<br><input type="submit" value="Validare"/>

</form>'; 

if(isset($_POST['admin']))
{
$admin=$_POST['admin'];
}

if($admin=="qwq")
{
echo'<meta HTTP-EQUIV="REFRESH" content="0; url=actualizareCalendar.php">';

}
else
{
	
	echo 'Este OK';
	$mesaj="S-a incercat accesul neautorizat la baza de date de la IP-ul ".$_SERVER['REMOTE_ADDR']; 
$mail=new TrimiteEmail("cdl_1996@yahoo.com",$mesaj,"actualizare");
	
}

?>