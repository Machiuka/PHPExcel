<?php
class TrimiteEmail {

//clasa necesara trimiterii unui email
//valoarea recurentei lunar, anual, la x ani, trimestrial sau semestrial
// define properties


// constructor 
    public function __construct($to, $body)

    { 
 

 if (mail($to, $subject, $body)) {
   //echo("<p>Email successfully sent!</p>");
  } else {
   echo("<p>Email delivery failed…</p>");
  }

}



}



?> 
